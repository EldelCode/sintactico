from flask import Flask, request,jsonify,render_template
import analizador_lexico as lex
from analizador_sintactico import parser

app=Flask('app')

@app.route("/")
def hello_world():
    return render_template('index.html')

@app.route('/api/v1/lexer', methods=['POST'])
def lexer():
    data = request.get_json()
    code = data.get('code')

    lex.lexer.input(code)

    tokens = []
    while True:
        if tok := lex.lexer.token():
            tokens.append(
                {
                    "type": tok.type,
                    "value": tok.value,
                    "line": tok.lineno,
                    "lexpos": tok.lexpos,
                })

        else:
            break

    print("Code:", code)
    print("Tokens", tokens)

    return render_template('result.html', code=code, tokens=tokens)

@app.route('/api/v1/parser', methods=['POST'])
def par():
    data = request.get_json()
    code = data.get('code')

    pepe = parser.parse(code)
 
        
    try:
        pepe = parser.parse(code)
    except Exception as e:
        print(e)

    return render_template('result.html', code=code, pepe=pepe)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)